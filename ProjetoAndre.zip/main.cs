using System;
using System.Collections.Generic;

class MainClass {

  public static void Main (string[] args) {

    Fornecedor  fornecedor = new Fornecedor();

    Estoque estoque = new Estoque();
    fornecedor.AssociarEstoque(estoque);

    int opcao = 0;
    
    Console.WriteLine ("Digite 1 para comprarmos um produto: /n 2 para vendermos um produto em estoque: ");
    opcao = int.Parse(Console.ReadLine());
    

    while(opcao == 1 || opcao == 2 || opcao == 3){
       Console.WriteLine ("Digite 1 para comprarmos um produto: /n 2 para vendermos um produto em estoque: ");
       opcao = int.Parse(Console.ReadLine());
      if (opcao == 1){
        Console.WriteLine("Empresa Fornecedora:");
        string empresa = Console.ReadLine();
        
        Console.WriteLine("Qual produto esta sendo adquirido:");
        string produto = Console.ReadLine();

        Console.WriteLine("Entre com o código do produto:");
        int codproduto = int.Parse(Console.ReadLine());
       
        Console.WriteLine("Quantidade sendo adquirida:");
        int quantidade = int.Parse(Console.ReadLine());
        
        Console.WriteLine("Valor de cada produto:");
        float valorproduto = float.Parse(Console.ReadLine());

        Fornecedor listaforne = fornecedor.ComprarProduto(empresa,produto,codproduto,quantidade,valorproduto);

        estoque.MostrarFornecedor();
      }
      if(opcao == 2){
        estoque.MostrarFornecedor();


        Console.WriteLine("Nome do Cliente:");
        string nomecliente = Console.ReadLine();
        
        Console.WriteLine("E-mail do Cliente:");
        string emailcliente = Console.ReadLine();
        
        Console.WriteLine("Quantidade que irá comprar:");
        int quantcompra =int.Parse (Console.ReadLine());

        Console.WriteLine("Valor de revenda:");
        float valorrevenda = float.Parse (Console.ReadLine());
       
      }
     
    }
  }
}